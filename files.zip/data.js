/* =========================================================
   REPERTORIO — MARO MUSIC
   -----------------------------------------------------------
   Para AGREGAR una canción: copia una línea dentro del género
   correspondiente y cambia "title" y "artist".
   Para AGREGAR un género nuevo: copia un bloque completo
   { genre: "...", songs: [...] } y ajústalo.
   Esta es una lista de EJEMPLO — reemplázala por tu repertorio real.
   ========================================================= */

const REPERTOIRE = [
  {
    genre: "Salsa Romántica",
    songs: [
      { title: "Vivir Mi Vida", artist: "Marc Anthony" },
      { title: "El Cantante", artist: "Héctor Lavoe" },
      { title: "Aguanilé", artist: "Héctor Lavoe" },
      { title: "Todo Tiene Su Final", artist: "Héctor Lavoe" },
      { title: "Pégate", artist: "Ricky Martin" },
      { title: "Que Manera de Quererte", artist: "Rey Ruiz" },
      { title: "Nadie Como Ella", artist: "Rey Ruiz" },
    ],
  },
  {
    genre: "Rock en Español",
    songs: [
      { title: "De Música Ligera", artist: "Soda Stereo" },
      { title: "Persiana Americana", artist: "Soda Stereo" },
      { title: "La Flaca", artist: "Jarabe de Palo" },
      { title: "Clavado en un Bar", artist: "Maná" },
      { title: "Rayando el Sol", artist: "Maná" },
      { title: "Eres", artist: "Café Tacvba" },
      { title: "Lamento Boliviano", artist: "Enanitos Verdes" },
    ],
  },
  {
    genre: "Baladas Románticas",
    songs: [
      { title: "Amor Eterno", artist: "Juan Gabriel" },
      { title: "Contigo Aprendí", artist: "Armando Manzanero" },
      { title: "Historia de un Amor", artist: "Carlos Eleta Almarán" },
      { title: "Yo No Te Pido La Luna", artist: "Daniela Romo" },
      { title: "Un Siglo Sin Ti", artist: "Chayanne" },
      { title: "Y Cómo Es Él", artist: "José José" },
    ],
  },
  {
    genre: "Tropical",
    songs: [
      { title: "La Bilirrubina", artist: "Juan Luis Guerra" },
      { title: "Ojalá Que Llueva Café", artist: "Juan Luis Guerra" },
      { title: "La Gota Fría", artist: "Carlos Vives" },
      { title: "La Camisa Negra", artist: "Juanes" },
      { title: "Burbujas de Amor", artist: "Juan Luis Guerra" },
    ],
  },
  {
    genre: "Música Popular",
    songs: [
      { title: "Las Tumbas", artist: "Darío Gómez" },
      { title: "Nadie es Eterno en el Mundo", artist: "Darío Gómez" },
      { title: "Volver, Volver", artist: "Vicente Fernández" },
      { title: "El Rey", artist: "Vicente Fernández" },
      { title: "Amarga Navidad", artist: "Vicente Fernández" },
    ],
  },
];
